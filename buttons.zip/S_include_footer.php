<!--footer start-->
    <footer class="site-footer">
      <div class="text-center">
        <p>
          &copy; Copyrights <strong>DANGO BEN</strong>. All Rights Reserved
        </p>
        <div class="credits">
          Created by <a href="https:mailto:dangoben601@gmail.com/">Dango ben issouf</a>
        </div>
        <a href="panels.html#" class="go-top">
          <i class="fa fa-angle-up"></i>
          </a>
      </div>
    </footer>
<!--footer end-->