<?php
SESSION_START();
include('connect_data.php');

if (isset($_POST['datebegin']) && isset($_POST['date_end']) && isset($_POST['time_begin']) && isset($_POST['time_end']) && isset($_POST['titre']) && isset($_POST['note']) ) {

   $user_demandeur=htmlspecialchars($_POST['user_demandeur']);
   $user_receveur=htmlspecialchars($_POST['user_receveur']);
   $titre=htmlspecialchars($_POST['titre']);
   $note=htmlspecialchars($_POST['note']);
   $date_begin=htmlspecialchars($_POST['datebegin']);
   $date_end=htmlspecialchars($_POST['date_end']);
   $time_begin=htmlspecialchars($_POST['time_begin']);
   $time_end=htmlspecialchars($_POST['time_end']);

        $req = $bdd->prepare('INSERT INTO rdv (user_demandeur, user_receveur, date_debut, heure_debut, date_fin, heure_fin, titre, statu, notes, dateposte ) VALUES(:user_demandeur, :user_receveur, :date_debut, :heure_debut, :date_fin, :heure_fin, :titre, :statu, :notes, NOW() ) ');
        $req->execute(array(
             'user_demandeur' => $user_demandeur,
             'user_receveur' => $user_receveur,
             'date_debut' => $date_begin,
             'heure_debut' => $time_begin,
             'date_fin' => $date_end,
             'heure_fin' => $time_end,
             'titre' => $titre,
             'statu' => 'attente',
             'notes' => $note
        )); 

        $reponse =  'VOTRE RENDEZ-VOUS A BIEN ETE PRIS MERCI!';
        header("location:profile.php?profile=".$user_receveur."&aff_reponse=".$reponse);
        
}
else{
  $reponse =  'REMPLISSEZ TOUS LES CHAMPS DU FORMULAIRE SVP.';
  header("location:profile.php?profile=".$user_receveur."&aff_reponse_fausse=".$reponse);
}

?>